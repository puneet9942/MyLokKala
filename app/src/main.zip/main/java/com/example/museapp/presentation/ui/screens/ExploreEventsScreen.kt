package com.example.museapp.presentation.ui.screens

import android.location.Location
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.museapp.domain.model.ExploreEvent
import com.example.museapp.presentation.feature.exploreevents.ExploreEventViewModel
import com.example.museapp.ui.theme.AppTypography

@Composable
fun ExploreEventsScreen(
    viewModel: ExploreEventViewModel = hiltViewModel(),
    loc: Location
) {

    val state = viewModel.uiState

    LaunchedEffect(Unit) {
        viewModel.fetchExploreEvents(loc)
    }

    if (state.selectedEvent != null) {
        ExploreEventDetailScreen(
            event = state.selectedEvent,
            onBack = { viewModel.onBackFromDetail() }
        )
    } else {
        when {
            state.isLoading -> CircularProgressIndicator()

            state.error != null -> Text(state.error ?: "")

            else -> {
                LazyColumn {
                    items(state.events) { event ->
//                        ExploreEventItem(
//                            event = event,
//                            onClick = { viewModel.onEventClick(event) }
//                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExploreEventItem(
    event: ExploreEvent,
    onClick: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(12.dp)
    ) {

        Text(event.title, style = AppTypography.bodySmall)
        Text(event.date, style = AppTypography.bodySmall)
        Text(event.location, style = AppTypography.bodySmall)
    }
}

@Composable
fun ExploreEventDetailScreen(
    event: ExploreEvent,
    onBack: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "← Back",
            modifier = Modifier.clickable { onBack() }
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(event.title, style = AppTypography.titleLarge)

        Text(event.date)
        Text(event.location)

        Spacer(modifier = Modifier.height(16.dp))

        if (event.ticketLink.isNotEmpty()) {
            Text(
                text = "Book Tickets",
                color = Color.Blue,
                modifier = Modifier.clickable {
                    // use your existing openUrl util
                }
            )
        }
    }
}