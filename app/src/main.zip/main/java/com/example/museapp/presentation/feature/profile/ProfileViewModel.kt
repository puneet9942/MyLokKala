package com.example.museapp.presentation.feature.profile

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.museapp.data.util.NetworkResult
import com.example.museapp.domain.repository.ProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val repository: ProfileRepository
) : ViewModel() {

    private val TAG = "ProfileViewModel"

    private val _uiState = MutableStateFlow<ProfileUiStates>(ProfileUiStates.Idle)
    val uiState: StateFlow<ProfileUiStates> = _uiState.asStateFlow()

    fun submitEvent(event: ProfileEvents) {
        when (event) {
            ProfileEvents.LoadProfile -> loadProfileIfNeeded()
            ProfileEvents.RefreshProfile -> refreshProfile()
        }
    }

    private fun loadProfileIfNeeded() {
        viewModelScope.launch {
            _uiState.value = ProfileUiStates.Loading
            try {
                val sessionFetched = repository.hasFetchedProfileInSession()
                Log.d(TAG, "sessionFetched=$sessionFetched")
                if (!sessionFetched) {
                    when (val res = repository.getProfile(forceNetwork = true)) {
                        is NetworkResult.Success -> {
                            val raw = repository.getCachedProfileResponse()
                            _uiState.value = ProfileUiStates.ShowingRemote(res.data, raw)
                        }
                        is NetworkResult.Error -> {
                            val cached = repository.getCachedProfile()
                            val raw = repository.getCachedProfileResponse()
                            if (cached != null) _uiState.value = ProfileUiStates.ShowingCached(cached, raw)
                            else _uiState.value = ProfileUiStates.Error(res.message ?: "Unknown")
                        }
                    }
                } else {
                    val cached = repository.getCachedProfile()
                    val raw = repository.getCachedProfileResponse()
                    if (cached != null) _uiState.value = ProfileUiStates.ShowingCached(cached, raw)
                    else {
                        when (val res = repository.getProfile(forceNetwork = true)) {
                            is NetworkResult.Success -> {
                                val raw2 = repository.getCachedProfileResponse()
                                _uiState.value = ProfileUiStates.ShowingRemote(res.data, raw2)
                            }
                            is NetworkResult.Error -> _uiState.value = ProfileUiStates.Error(res.message ?: "Unknown")
                        }
                    }
                }
            } catch (t: Throwable) {
                _uiState.value = ProfileUiStates.Error(t.message ?: "Unknown error")
            }
        }
    }

    private fun refreshProfile() {
        viewModelScope.launch {
            _uiState.value = ProfileUiStates.Loading
            when (val res = repository.getProfile(forceNetwork = true)) {
                is NetworkResult.Success -> {
                    val raw = repository.getCachedProfileResponse()
                    _uiState.value = ProfileUiStates.ShowingRemote(res.data, raw)
                }
                is NetworkResult.Error -> _uiState.value = ProfileUiStates.Error(res.message ?: "Unknown")
            }
        }
    }
}
