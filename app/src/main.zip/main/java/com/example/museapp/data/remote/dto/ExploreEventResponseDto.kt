package com.example.museapp.data.remote.dto

import com.google.gson.annotations.SerializedName

data class ExploreEventResponseDto(
    val events_results: List<ExploreEventDto>?
)

data class ExploreEventDto(
    val title: String?,
    val date: ExploreEventDateDto?,
    val address: List<String>?,
    val link: String?,
    val ticket_info: List<ExploreEventTicketInfoDto>?,
    val thumbnail: String?,
    val description: String?
)

data class ExploreEventDateDto(
    val start_date: String?,

    @SerializedName("when")
    val whenValue: String?
)

data class ExploreEventTicketInfoDto(
    val source: String?,
    val link: String?
)