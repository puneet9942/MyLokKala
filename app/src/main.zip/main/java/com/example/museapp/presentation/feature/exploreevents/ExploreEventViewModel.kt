package com.example.museapp.presentation.feature.exploreevents

import android.location.Location
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.museapp.domain.usecase.GetExploreEventsUseCase
import com.example.museapp.util.LocationProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExploreEventViewModel @Inject constructor(
    private val getExploreEventsUseCase: GetExploreEventsUseCase,
    private val locationProvider: LocationProvider
) : ViewModel() {

    var uiState by mutableStateOf(ExploreEventUiState())
        private set

    fun fetchExploreEvents(loc: Location) {
        viewModelScope.launch {

            val area = locationProvider.getAreaFromLocation(loc)

            uiState = uiState.copy(isLoading = true)

            val result = getExploreEventsUseCase("events in $area")

            uiState = if (result.isSuccess) {
                uiState.copy(
                    isLoading = false,
                    events = result.getOrDefault(emptyList())
                )
            } else {
                uiState.copy(
                    isLoading = false,
                    error = result.exceptionOrNull()?.message
                )
            }
        }
    }

//    fun onEventClick(event: Int) {
//        uiState = uiState.copy(selectedEvent = event)
//    }

    fun onBackFromDetail() {
        uiState = uiState.copy(selectedEvent = null)
    }
}