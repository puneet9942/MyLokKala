package com.example.museapp.data.remote.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Response data wrapper for profile update. We expect the backend to return the updated user object.
 * Many APIs in the project return "data": { "user": { ... } } or direct user DTO.
 * This DTO attempts to match the common shape: data.user -> UserDto
 */
@JsonClass(generateAdapter = true)
data class ProfileDataDto(
    @Json(name = "user") val user: UserDto? = null
)
