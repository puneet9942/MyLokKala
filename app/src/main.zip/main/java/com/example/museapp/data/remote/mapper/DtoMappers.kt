package com.example.museapp.data.remote.mapper

import com.example.museapp.data.remote.dto.*
import com.example.museapp.domain.model.*
import java.util.UUID

/**
 * Defensive DTO -> Domain mappers.
 *
 * This file declares mapping functions for multiple DTO name variants that might exist
 * in your project (InterestDto vs InterestItemDto, FavoriteUserDto vs FavoritedUserDto, etc.)
 * to avoid "none of the candidates is applicable" compiler errors.
 */

/* -------------------- Interest -------------------- */
/** Map DTO variant InterestItemDto -> Interest domain */

/** Map older InterestDto shape (id / remote_id / name) */
fun InterestDto.toDomain(): Interest {
    val remote = this.id ?: this.remoteId
    val display = this.name?.trim().takeUnless { it.isNullOrBlank() } ?: "Unknown"
    return Interest(id = null, remoteId = remote, name = display)
}

/* -------------------- User summary (favorite list) -------------------- */
/** Map summary user returned inside favoriteUsers -> domain.User */
fun UserSummaryDto.toDomainSummary(): User {
    return User(
        id = this.id ?: "",
        fullName = this.fullName,
        profileDescription = null,
        lat = null,
        lng = null,
        phone = null,
        bio = null,
        isEventManager = null,
        priceMin = null,
        priceMax = null,
        photo = this.photo,
        photos = emptyList(),
        videos = emptyList(),
        createdAt = null,
        updatedAt = null,
        interests = emptyList(),
        averageRating = 0.0,
        totalRatings = 0,
        facebookId = null,
        twitterId = null,
        instagramId = null,
        linkedinId = null,
        youtubeId = null,
        dob = null,
        pricingType = this.pricingType,
        standardPrice = null,
        travelRadius = null,
        gender = this.gender
    )
}

/* -------------------- FavoriteUser mapping -------------------- */
/** Map DTO FavoriteUserDto -> domain.FavoriteUser (robust) */
fun FavoriteUserDto.toDomain(): FavoriteUser {
    val domainUser = this.favoriteUser?.toDomainSummary() ?: User(id = "", fullName = null)
    return FavoriteUser(
        id = this.id ?: "",
        favoriteUser = domainUser,
        createdAt = this.createdAt
    )
}

/* -------------------- ProfileDto -> User -------------------- */
fun ProfileDto.toDomain(): User {
    // interests
    val interestsList: List<Interest> = this.interests?.mapNotNull { it?.toDomain() } ?: emptyList()

    // photos and videos safe lists
    val photosList: List<String> = this.profilePhotos ?: emptyList()
    val videosList: List<String> = this.profileVideos ?: emptyList()

    // favorites -> domain
    val favoritesList = this.favoriteUsers?.mapNotNull { it?.toDomain() } ?: emptyList()

    return User(
        id = this.id ?: "",
        fullName = this.fullName ?: "",
        profileDescription = this.profileDescription ?: this.bio,
        lat = this.latitude,
        lng = this.longitude,
        phone = this.phone,
        bio = this.bio,
        isEventManager = this.isEventManager ?: false,
        priceMin = this.priceMin,
        priceMax = this.priceMax,
        photo = this.photo,
        photos = photosList,
        videos = videosList,
        createdAt = this.createdAt,
        updatedAt = this.updatedAt,
        interests = interestsList,
        averageRating = this.averageRating ?: 0.0,
        totalRatings = this.totalRatings ?: 0,
        facebookId = this.facebookId,
        twitterId = this.twitterId,
        instagramId = this.instaId,
        linkedinId = null,
        youtubeId = this.youtubeId,
        dob = this.dob,
        pricingType = this.pricingType,
        standardPrice = this.standardPrice?.toDouble(),
        travelRadius = this.travelRadius?.toDouble(),
        gender = this.gender
    )
}

/* -------------------- Other DTO -> Domain helpers (older shapes) -------------------- */
/** Map UserDto (full user DTO used elsewhere) -> User */
fun UserDto.toDomain(): User {
    val domainInterests = this.interests?.mapNotNull { it?.toDomain() } ?: emptyList()
    return User(
        id = this.id ?: "",
        fullName = this.fullName ?: "",
        profileDescription = this.profile_description,
        lat = this.lat,
        lng = this.lng,
        phone = this.phone,
        bio = this.bio,
        isEventManager = this.isEventManager ?: false,
        priceMin = this.priceMin,
        priceMax = this.priceMax,
        photo = this.photo,
        photos = this.photos ?: emptyList(),
        videos = this.videos ?: emptyList(),
        createdAt = this.createdAt,
        updatedAt = this.updatedAt,
        interests = domainInterests,
        averageRating = this.averageRating ?: 0.0,
        totalRatings = this.totalRatings ?: 0,
        facebookId = this.facebookId,
        twitterId = this.twitterId,
        instagramId = this.instagramId,
        linkedinId = null,
        youtubeId = this.youtubeId,
        dob = this.dob,
        pricingType = this.pricingType,
        standardPrice = this.standardPrice?.toDouble(),
        travelRadius = this.travelRadius?.toDouble(),
        gender = this.gender
    )
}
