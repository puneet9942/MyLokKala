package com.example.museapp.data.repository

import com.example.museapp.data.remote.ApiService
import com.example.museapp.data.remote.mapper.toDomain
import com.example.museapp.domain.model.ExploreEvent
import com.example.museapp.domain.repository.ExploreEventRepository
import com.example.museapp.BuildConfig

class ExploreEventRepositoryImpl(
    private val apiService: ApiService
) : ExploreEventRepository {

    override suspend fun getExploreEvents(query: String): Result<List<ExploreEvent>> {
        return try {
            val response = apiService.getExploreEvents(
                query = query,
                apiKey = BuildConfig.SERP_API_KEY
            )

            // ✅ using extension mapper
            Result.success(response.toDomain())

        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}