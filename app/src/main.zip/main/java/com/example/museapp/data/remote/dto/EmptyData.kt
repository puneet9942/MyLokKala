package com.example.museapp.data.remote.dto

data class EmptyData(val ignored: String = "")