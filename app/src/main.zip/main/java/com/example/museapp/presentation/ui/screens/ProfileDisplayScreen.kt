package com.example.museapp.presentation.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.rememberAsyncImagePainter
import com.example.museapp.domain.model.Interest
import com.example.museapp.presentation.feature.profile.ProfileEvents
import com.example.museapp.presentation.feature.profile.ProfileUiStates
import com.example.museapp.presentation.feature.profile.ProfileViewModel
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileDisplayScreen(
    viewModel: ProfileViewModel = hiltViewModel(),
    onBack: () -> Unit = {}
) {
    val state by viewModel.uiState.collectAsState()

    // Trigger load once when screen enters
    LaunchedEffect(Unit) {
        viewModel.submitEvent(ProfileEvents.LoadProfile)
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Profile") },
                navigationIcon = {
                    androidx.compose.material3.IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier
            .fillMaxWidth()
            .padding(paddingValues)
        ) {
            when (state) {
                is ProfileUiStates.Idle -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Idle")
                    }
                }
                is ProfileUiStates.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is ProfileUiStates.Error -> {
                    val msg = (state as ProfileUiStates.Error).message
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "Error: $msg", color = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { viewModel.submitEvent(ProfileEvents.RefreshProfile) }) {
                            Text("Retry")
                        }
                    }
                }
                is ProfileUiStates.ShowingCached -> {
                    val st = state as ProfileUiStates.ShowingCached
                    ProfileDetailContent(user = st.user, onRefresh = { viewModel.submitEvent(ProfileEvents.RefreshProfile) }, rawDtoString = st.rawDto?.let { it.toString() })
                }
                is ProfileUiStates.ShowingRemote -> {
                    val st = state as ProfileUiStates.ShowingRemote
                    ProfileDetailContent(user = st.user, onRefresh = { viewModel.submitEvent(ProfileEvents.RefreshProfile) }, rawDtoString = st.rawDto?.let { it.toString() })
                }
            }
        }
    }
}

@Composable
private fun ProfileDetailContent(
    user: com.example.museapp.domain.model.User,
    onRefresh: () -> Unit,
    rawDtoString: String? = null
) {
    val uriHandler = LocalUriHandler.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // main profile photo
        val photoUrl = user.photo
        if (!photoUrl.isNullOrBlank()) {
            Image(
                painter = rememberAsyncImagePainter(model = photoUrl),
                contentDescription = "Profile photo",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No photo", fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Basic info
        Text(
            text = user.fullName ?: "Unknown",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = "Phone: ${user.phone ?: "—"}", fontSize = 14.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Gender: ${user.gender ?: "—"}", fontSize = 14.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "DOB: ${user.dob ?: "—"}", fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        // Pricing
        Text(text = "Pricing Type: ${user.pricingType ?: "—"}")
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Standard price: ${user.standardPrice?.toString() ?: "—"}")
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Price range: ${user.priceMin?.toString() ?: "—"} — ${user.priceMax?.toString() ?: "—"}")
        Spacer(modifier = Modifier.height(8.dp))

        // Travel
        Text(text = "Travel radius (km): ${user.travelRadius?.toString() ?: "—"}")
        Spacer(modifier = Modifier.height(8.dp))

        // Bio / description
        Text(text = "Bio", fontWeight = FontWeight.SemiBold)
        Text(text = user.bio ?: user.profileDescription ?: "—")
        Spacer(modifier = Modifier.height(12.dp))

        // Interests
        Text(text = "Interests", fontWeight = FontWeight.SemiBold)
        if (user.interests.isNotEmpty()) {
            Column {
                user.interests.forEach { interest ->
                    InterestRow(interest)
                }
            }
        } else {
            Text("No interests")
        }
        Spacer(modifier = Modifier.height(12.dp))

        // Photos gallery
        Text(text = "Photos", fontWeight = FontWeight.SemiBold)
        if (user.photos.isNotEmpty()) {
            Column {
                user.photos.forEach { url ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Image(
                        painter = rememberAsyncImagePainter(model = url),
                        contentDescription = "photo",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        } else {
            Text("No gallery photos")
        }
        Spacer(modifier = Modifier.height(12.dp))

        // Videos (clickable URIs)
        Text(text = "Videos", fontWeight = FontWeight.SemiBold)
        if (user.videos.isNotEmpty()) {
            Column {
                user.videos.forEach { url ->
                    Text(
                        text = url,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { uriHandler.openUri(url) }
                            .padding(vertical = 6.dp),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        } else {
            Text("No profile videos")
        }
        Spacer(modifier = Modifier.height(12.dp))

        // Ratings
        Text(text = "Average rating: ${user.averageRating?.toString() ?: "—"} (${user.totalRatings ?: 0} ratings)")
        Spacer(modifier = Modifier.height(12.dp))

        // Socials
        Text(text = "Socials: IG ${user.instagramId ?: "—"} • Twitter ${user.twitterId ?: "—"} • YouTube ${user.youtubeId ?: "—"} • Facebook ${user.facebookId ?: "—"}")
        Spacer(modifier = Modifier.height(12.dp))

        // Raw DTO (optional)
        if (!rawDtoString.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Raw profile JSON (truncated):", fontWeight = FontWeight.SemiBold)
            Text(text = if (rawDtoString.length > 400) rawDtoString.take(400) + "..." else rawDtoString)
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Favorites placeholder
        Text(text = "Favorites", fontWeight = FontWeight.SemiBold)
        Text("Favorites will appear here if available.")
        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = onRefresh) {
            Text("Refresh (force network)")
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
private fun InterestRow(interest: Interest) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(text = interest.name ?: "Unknown")
    }
}
