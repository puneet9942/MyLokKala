package com.example.museapp.data.remote.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * Payload DTO used by the backend inside the multipart "payload" JSON part.
 * Matches your example:
 * {"fullName":"John Doe","dob":"1990-01-15","gender":"male","profileDescription":"drum artist","bio":"...","pricingType":"fixed", ... }
 */
@JsonClass(generateAdapter = true)
data class ProfileRequestDto(
    @Json(name = "fullName") val fullName: String,
    @Json(name = "dob") val dob: String,
    @Json(name = "gender") val gender: String? = null,
    @Json(name = "profileDescription") val profileDescription: String? = null,
    @Json(name = "bio") val bio: String? = null,
    @Json(name = "pricingType") val pricingType: String? = null,
    @Json(name = "standardPrice") val standardPrice: Int? = null,
    @Json(name = "priceMin") val priceMin: Int? = null,
    @Json(name = "priceMax") val priceMax: Int? = null,
    @Json(name = "travelRadius") val travelRadius: Int? = null,
    @Json(name = "isEventManager") val isEventManager: Boolean = false,
    @Json(name = "instaId") val instaId: String? = null,
    @Json(name = "twitterId") val twitterId: String? = null,
    @Json(name = "youtubeId") val youtubeId: String? = null,
    @Json(name = "facebookId") val facebookId: String? = null,
    @Json(name = "interests") val interests: List<String> = emptyList()
)
