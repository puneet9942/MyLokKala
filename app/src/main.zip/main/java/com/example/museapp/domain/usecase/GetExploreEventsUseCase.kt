package com.example.museapp.domain.usecase

import com.example.museapp.domain.repository.ExploreEventRepository

class GetExploreEventsUseCase(
    private val repository: ExploreEventRepository
) {
    suspend operator fun invoke(query: String) =
        repository.getExploreEvents(query)
}