package com.example.museapp.domain.model

data class Skill(
    val id: String,
    val name: String
)