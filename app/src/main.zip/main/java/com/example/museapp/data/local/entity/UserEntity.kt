package com.example.museapp.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserEntity(
    @PrimaryKey @ColumnInfo(name = "id") val id: String,
    @ColumnInfo(name = "full_name") val fullName: String? = null,
    @ColumnInfo(name = "profile_description") val profileDescription: String? = null,
    @ColumnInfo(name = "lat") val lat: Double? = null,
    @ColumnInfo(name = "lng") val lng: Double? = null,
    @ColumnInfo(name = "bio") val bio: String? = null,
    @ColumnInfo(name = "is_event_manager") val isEventManager: Boolean = false,
    @ColumnInfo(name = "phone") val phone: String? = null,
    @ColumnInfo(name = "price_min") val priceMin: Int? = null,
    @ColumnInfo(name = "price_max") val priceMax: Int? = null,
    @ColumnInfo(name = "photo") val photo: String? = null,
    @ColumnInfo(name = "photos_json") val photosJson: String? = null,
    @ColumnInfo(name = "videos_json") val videosJson: String? = null,
    @ColumnInfo(name = "created_at") val createdAt: String? = null,
    @ColumnInfo(name = "updated_at") val updatedAt: String? = null,
    @ColumnInfo(name = "interests_json") val interestsJson: String? = null,
    @ColumnInfo(name = "average_rating") val averageRating: Double? = null,
    @ColumnInfo(name = "total_ratings") val totalRatings: Int? = null,
    @ColumnInfo(name = "facebook_id") val facebookId: String? = null,
    @ColumnInfo(name = "twitter_id") val twitterId: String? = null,
    @ColumnInfo(name = "instagram_id") val instagramId: String? = null,
    @ColumnInfo(name = "linkedin_id") val linkedinId: String? = null,
    @ColumnInfo(name = "youtube_id") val youtubeId: String? = null,
    @ColumnInfo(name = "dob") val dob: String? = null,
    @ColumnInfo(name = "pricing_type") val pricingType: String? = null,
    @ColumnInfo(name = "standard_price") val standardPrice: Double? = null,
    @ColumnInfo(name = "travel_radius") val travelRadius: Double? = null,
    @ColumnInfo(name = "gender") val gender: String? = null,
    @ColumnInfo(name = "raw_json") val rawJson: String? = null
)
